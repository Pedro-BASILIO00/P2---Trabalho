using UnityEngine;
using UnityEngine.PlayerLoop;

public class TouchController : MonoBehaviour
{
    [SerializeField] Animator playerAnimator;
    [SerializeField] Transform playerTransform;
    [SerializeField] float walkSpeed;
    private int selectedDirection = 1;


    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                GameObject touchedBtn = hit.collider.gameObject;

                if (touchedBtn != null) { 
                
                    if (touchedBtn.CompareTag("btnUp"))
                    {
                        playerAnimator.SetFloat("Vertical", selectedDirection);
                        playerAnimator.SetFloat("Horizontal", 0);
                    } 
                    else if (touchedBtn.CompareTag("btnDown"))
                    {
                            playerAnimator.SetFloat("Vertical", -selectedDirection);
                            playerAnimator.SetFloat("Horizontal", 0);
                    }
                    else if (touchedBtn.CompareTag("btnRight"))
                    {
                        playerAnimator.SetFloat("Vertical", 0);
                        playerAnimator.SetFloat("Horizontal", selectedDirection);
                    }
                    else if (touchedBtn.CompareTag("btnLeft"))
                    {
                        playerAnimator.SetFloat("Vertical", 0);
                        playerAnimator.SetFloat("Horizontal", -selectedDirection);
                    }
                    
                }
            }

            
        }
        else
        {
            playerAnimator.SetFloat("Vertical", 0);
            playerAnimator.SetFloat("Horizontal", 0);
        }

        if (Input.GetMouseButtonUp(0)) {

            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                GameObject touchedBtn = hit.collider.gameObject;

                if (touchedBtn != null)
                {
                    if (touchedBtn.CompareTag("btnChange"))
                    {
                        selectedDirection *= -1;
                    }
                }
            }
        }

    }

    private void FixedUpdate()
    {
        Vector2 move = new Vector2(playerAnimator.GetFloat("Horizontal"), playerAnimator.GetFloat("Vertical")) * Time.deltaTime * walkSpeed;

        playerTransform.position = new Vector2 (Mathf.Clamp(playerTransform.position.x + move.x, -10, 10), 
                                                Mathf.Clamp(playerTransform.position.y + move.y, -10, 10));
    }

}
